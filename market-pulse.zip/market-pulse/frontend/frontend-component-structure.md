# Market Pulse — Frontend Component Structure

Single-page module, same stack as the rest of insidetrackapps.com (vanilla JS +
Supabase client + the API routes in `/api`). The Executive Dashboard
(`executive-market-dashboard.html`) is fully built as the reference screen; the
other four screens follow the same shell, tokens, and data-binding pattern.

## Shell

```
MarketPulseApp
├── TopBar            (logo, period selector, role badge, alert bell→AlertsDrawer)
├── NavTabs           (Executive · Ranking · Post Feed · City/Market · Response Quality)
├── <view slot>       (one screen mounts here)
└── AlertsDrawer      (live alert rows; ack button; filters by severity)
```

All views read through the caller-JWT Supabase client (RLS enforces company +
role). Writes go to the API routes, which re-check role server-side.

## A. Executive Dashboard — BUILT
KPI strip, top-competitor ranking with score bars, this-week mention split,
strongest-by-city, response opportunities, speed scoreboard. Data: `GET /api/scores`
+ `GET /api/posts?should_respond=true`.

## B. Competitor Ranking Dashboard
```
RankingView
├── Filters         (month, tier, city)
├── RankingTable
│     columns: rank · company · mentions · positive · unique recommenders ·
│              avg response · Google rating · review count · review velocity ·
│              popularity score · threat level
│     row→ CompetitorDrawer (profile, alias list, mention history, response samples)
└── WeightPanel     (admin only) sliders for the 8 scoring weights; must sum 100%;
                    "Recompute" → POST /api/scores/recompute
```
Data: `GET /api/scores` (ranking + components) and `GET /api/competitors`.

## C. Post Feed
```
PostFeedView
├── Filters         (city, platform, urgency, category, should-respond, search)
├── CaptureButton   → CapturePostModal (manual entry; records capture_method)
├── PostList
│     PostCard: platform · city · urgency chip · category · age ·
│               competitors mentioned (chips) · "ITG should respond" flag ·
│               analysis confidence
│     actions: [Analyze] POST /api/analyze · [Suggest replies] POST /api/suggest
│     row→ PostDrawer
│             ├── raw text + screenshot/source link
│             ├── MentionsTable (competitor, sentiment, who, unprompted)
│             ├── CompetitorResponses (type, tone, response time, effectiveness)
│             └── SuggestedResponses → ApprovalPanel
```
Data: `GET /api/posts` with filters.

## D. City / Market View
```
CityView
├── CityCards       (per market: leader, mention volume, ITG presence Y/N)
├── UnderservedList (cities with demand but no ITG mentions — opportunity)
├── EmergencyHeat   (cities ranked by emergency/high-urgency post volume)
└── CityDrawer      (per-city competitor ranking from city_rankings)
```
Data: `GET /api/scores` (`city_rankings`) + aggregates over `GET /api/posts`.

## E. Response Quality Dashboard
```
QualityView
├── BestResponses   (competitor_responses sorted by effectiveness_score desc)
├── WeakResponses   (lowest effectiveness; tone = pushy/generic/spammy)
├── ToneBreakdown   (counts by tone enum)
├── SpeedByCompany  (avg response minutes from v_competitor_speed_monthly)
└── ITGImprovements (AI "how ITG could do better" notes pulled from analysis)
```
Data: `GET /api/posts` (joined responses) + `GET /api/scores`.

## Approval Panel (shared component, Post Feed + drawers)
```
ApprovalPanel (per suggested_response)
├── body (editable textarea)        confidence badge
├── [Approve]  → POST /api/approvals {action:'approved'}        admin/mktg only
├── [Edit+Approve] → {action:'edited', edited_body}             admin/mktg only
├── [Reject]   → {action:'rejected'}                            admin/mktg only
├── [Copy]     (clipboard — human pastes into the platform manually)
├── [Mark responded] → {action:'marked_responded'}
├── [Assign to…]     → {action:'assigned', assigned_to}
└── deadline picker
```
The panel never posts to any external platform. "Copy" + "Mark responded" is the
v1 loop: a human posts, then records that they did.

## Role-Visibility Matrix

| Capability                              | admin | marketing_manager | reviewer | read_only_partner |
|-----------------------------------------|:-----:|:-----------------:|:--------:|:-----------------:|
| View all dashboards                     |  ✓    |        ✓          |    ✓     |        ✓          |
| Capture / edit posts & mentions         |  ✓    |        ✓          |    ✓     |        —          |
| Run AI analyze / generate suggestions   |  ✓    |        ✓          |    ✓     |        —          |
| Approve / edit / reject responses       |  ✓    |        ✓          |    —     |        —          |
| Manage competitors & aliases            |  ✓    |        ✓          |    —     |        —          |
| Adjust scoring weights / recompute      |  ✓    |        ✓          |    —     |        —          |
| Manage sources, groups, users           |  ✓    |        —          |    —     |        —          |
| View audit log                          |  ✓    |        —          |    —     |        —          |

Enforced twice: RLS policies in `schema.sql` (the real boundary) and a fast
role check at the top of each write route. `read_only_partner` is SELECT-only.
